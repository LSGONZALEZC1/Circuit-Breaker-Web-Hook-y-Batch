package com.co.Gonzalez.laura.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.Gonzalez.laura.orquestador.GiraffeEnigmaOrchestrator;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/orques/steps")
public class GetStepOrquestadorController {

    @Autowired
    private GiraffeEnigmaOrchestrator orchestrator;

    @PostMapping("/orchestration")
    public Mono<ResponseEntity<String>> startOrchestration() {
        return orchestrator.solveEnigma()
                .map(ResponseEntity::ok); // se realiza el envio de la respuesta final
    }
}