package com.co.Gonzalez.laura.batch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.co.Gonzalez.laura.orquestador.GiraffeEnigmaOrchestrator;

import reactor.core.publisher.Mono;

@Service
public class OrchestratorBatchService {
    @Autowired
    private GiraffeEnigmaOrchestrator orchestrator;


    @Scheduled(fixedRate = 120000)
    public void executeBatch() {
        Mono<String> result = orchestrator.solveEnigma(); // se llama al orquestador
        result.subscribe(response -> System.out.println("Batch result: " + response));
    }
}
